#include "$projectname$.h"

#include <QToolBar>
#include <QAction>
#include <QMenu>

$projectname$::$projectname$()
{
    _pluginCategory = "Undefined";
    _pluginName = tr("$projectname$");
}

$projectname$::~$projectname$()
{

}

void $projectname$::setupUi(QToolBar *toolBar, QMenu *menu)
{

}